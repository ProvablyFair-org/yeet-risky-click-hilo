YEET RISKY CLICK AND HILO: REPORT AND EVIDENCE
ProvablyFair.org, 23 November 2026

THE FINDING
YEET advertised Risky Click and HiLo at 99% RTP, a 1% house edge. Until
10 November 2026 both games took that 1% again on every tile and every call.
A round of n steps returned 0.99^n of the stake, not 99%:

  Risky Click, full board (9 tiles)       8.65% house edge
  HiLo, 25 calls (longest public win)    22.22% house edge
  HiLo, 49 calls (50-card limit)         38.89% house edge

A multi-step game advertised at 99% should return 99% for the whole round,
however many steps you take. The 1% comes off once. On 10 November YEET
switched both games to exactly that, and its Risky Click rules now say so.
By 23 November we had found no announcement on X or in YEET's Discord,
and no refund notice.

OPEN THE REPORT
Unzip with the folders intact and open yeet-risky-click-hilo-investigation.html
in a browser. It uses local images, no scripts, no trackers and no logins.
Links to evidence/ open the files in this package.

WHAT IS INSIDE
evidence/historical     40 public wins from YEET's own Top Wins and Lucky Wins
                        boards (20 HiLo, 20 Risky Click), collected on
                        23 November 2026: the public records, their hashes and
                        a script that rechecks every number.
evidence/risky-receipts The individual public receipt for each of the 20 Risky
                        Click wins. They match the leaderboard rows.
evidence/current        50 receipts we kept from our test account on
                        23 November 2026 (20 HiLo, 30 Risky Click), after
                        the change.
evidence/advertising    What players were told: logged-out page text saved on
                        6 November 2026, and public settings, rules and code
                        saved on 22 November 2026.
evidence/edge-model     The house edge for every round length from 1 to 49
                        steps, and a worked 49-call example.
evidence/public-search  Our X search for a YEET correction notice, three
                        official YEET posts and a check of one public player
                        screenshot.
evidence/discord        Our check of YEET's Discord: announcements, patch notes
                        and searches, plus a June 2025 post from a YEET team
                        member listing Risky Click at 99% RTP.
images                  14 receipt crops from our test bets and one public
                        player screenshot, with an index of hashes and sources.
SHA256SUMS              A hash for every file. verify_package.py checks them.
LICENSE                 MIT for the scripts, CC BY 4.0 for our text and
                        analysis. Third-party material stays with its owners.

CHECK IT YOURSELF
Python 3.9 or later, standard library only. No account, no network, no
wagering. From this folder:

    python3 verify_package.py
    python3 evidence/historical/verify.py --output /tmp/yeet-historical
    python3 evidence/risky-receipts/verify.py --output /tmp/yeet-risky-receipts
    python3 evidence/current/verify.py --output /tmp/yeet-current
    python3 evidence/edge-model/verify.py --output /tmp/yeet-edge
    python3 evidence/public-search/verify_public_image.py

Each verify.py writes fresh results to the folder you name, which must be
outside this package. They match the bundled analysis files byte for byte.
verify_package.py works the same on a git clone; it skips the .git folder.

EXPECTED RESULTS
Before the change (YEET's public records):
  HiLo: 20 wins, 163 winning calls. Every call matches 1% taken on every
  call. None of the 143 calls after the first matches 1% taken once.
  Longest win: 25 calls.
  Risky Click: 20 wins. Every multiplier is the plain product of the tile
  multipliers, which is 1% on every tile. None matches 1% taken once.
  All 20 individual receipts match their leaderboard rows.
  The 40 wins paid $1,020,262.93. Priced at 99% for the round they pay
  $39,789.55 more.
After the change (our test receipts):
  50 receipts kept, 17 wins (6 HiLo, 11 Risky Click). All 17 match 1% taken
  once. The 30 Risky Click receipts are one complete 17-round session plus
  13 of the 40 rounds from an earlier session.
  All 27 HiLo calls after the first rule out 1% on every call.

LIMITS
- The 40 public wins are YEET's top and lucky wins. They show how wins were
  priced. They are not all play, so $39,789.55 is not a total.
- Risky Click receipts do not show which tiles were picked. Nine wins fit more
  than one set of tiles. For those we use the set with the smallest
  difference.
- 49 HiLo calls comes from the 50-card limit on every public receipt. We did
  not see a 49-call bet. The longest public win has 25 calls.
- The 10 November switch date comes from YEET's file dates and the last
  old-price public win. We cannot see YEET's server.
- This checks payout pricing. It does not replay the random draws.
- Each source records the date it was collected. Hashes show the files have
  not changed since. They are not independent timestamps.
- We checked X and YEET's Discord. We cannot see emails, private messages
  or account credits.
- Our test bet IDs are published, so YEET can identify those bets.

CORRECTIONS
Send corrections or new evidence to audit@provablyfair.org. We date and
publish material corrections.
